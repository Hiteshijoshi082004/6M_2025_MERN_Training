import "./Introduction.css"
function Introduction(){
    return(
        <>
        <h1 className="class-box">My name is Hiteshi Joshi</h1>
        <div>I am pursuing BTech in CSE from GNDU</div>
        <div>I live in jalandhar</div>
        <img src="react.svg" alt="" />
        </>
    )
}
 export default Introduction